import tkinter as tk
from tkinter import messagebox
import math
import re
from PIL import ImageTk, Image 
class Calculator:
    def __init__(self, root):
        self.root = root
        self.root.title("python版计算器")
        icon_image = ImageTk.PhotoImage(Image.open("c5b7446181d8185280839faee7970fa.png"))  
        root.iconphoto(False, icon_image)
        # 初始化计算器状态
        self.current_input = ""      # 当前输入内容
        self.memory = ""             # 记忆内容（用于CE功能）
        self.is_hex_mode = False     # 是否十六进制模式
        
        # 创建界面布局
        self.create_ui()
        
        # CRC16预计算表
        self.crc16_table = [
            0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241,   
        ]
    
    def create_ui(self):
        """创建计算器用户界面"""
        # 主显示区域
        self.display = tk.Text(self.root, height=2, width=30, font=('Arial', 22))
        self.display.grid(row=0, column=0, columnspan=5, padx=10, pady=10)
        
        # 数字按钮 (0-9)
        for i in range(1, 10):
            btn = tk.Button(self.root, text=str(i), width=5, 
                          command=lambda x=i: self.append_input(str(x)))
            btn.grid(row=(i-1)//3 + 1, column=(i-1)%3)
        
        # 0按钮单独处理
        tk.Button(self.root, text="0", width=5, command=lambda: self.append_input("0")).grid(row=4, column=1)
        
        # 基础运算符 (+, -, *, /)
        operators = ['+', '-', '*', '/']
        for i, op in enumerate(operators):
            btn = tk.Button(self.root, text=op, width=5, 
                          command=lambda x=op: self.append_input(x))
            btn.grid(row=i+1, column=3)
        
        # 等号按钮
        tk.Button(self.root, text="=", width=5, command=self.calculate_result).grid(row=4, column=2)
        
        # 清除按钮 (CE)
        tk.Button(self.root, text="CE", width=5, command=self.clear_entry).grid(row=4, column=0)
        
        # 退格按钮
        tk.Button(self.root, text="←", width=5, command=self.backspace).grid(row=1, column=4)
        
        # 高级功能按钮
        advanced_ops = ['√', '^', 'log', 'sin', 'cos', 'tan', '!', 'π', 'e']
        for i, op in enumerate(advanced_ops):
            btn = tk.Button(self.root, text=op, width=5, 
                          command=lambda x=op: self.handle_advanced_op(x))
            btn.grid(row=i//2 + 2, column=4 + i%2)
        
        # 进制转换按钮
        tk.Button(self.root, text="Dec→Bin", width=10, command=self.dec_to_bin).grid(row=6, column=0, columnspan=2)
        tk.Button(self.root, text="Dec→Hex", width=10, command=self.dec_to_hex).grid(row=6, column=2, columnspan=2)
        
        # CRC16按钮
        tk.Button(self.root, text="CRC16", width=10, command=self.calculate_crc16).grid(row=7, column=0, columnspan=2)
        
        # 十六进制按钮 (A-F)
        hex_buttons = ['A', 'B', 'C', 'D', 'E', 'F']
        for i, char in enumerate(hex_buttons):
            btn = tk.Button(self.root, text=char, width=5, 
                          command=lambda x=char: self.append_hex(x))
            btn.grid(row=i//3 + 5, column=i%3)
    
    def append_input(self, char):
        """追加输入到当前表达式"""
        self.current_input += char
        self.update_display()
    
    def append_hex(self, char):
        """追加十六进制字符输入"""
        if not self.is_hex_mode:
            messagebox.showinfo("提示", "请在十六进制模式下使用A-F按钮")
            return
        self.append_input(char)
    
    def update_display(self):
        """更新显示区域内容"""
        self.display.delete(1.0, tk.END)
        self.display.insert(tk.END, self.current_input)
    
    def clear_entry(self):
        """清除当前输入，保存到记忆区"""
        self.memory = self.current_input
        self.current_input = ""
        self.update_display()
    
    def backspace(self):
        """删除最后一个字符"""
        self.current_input = self.current_input[:-1]
        self.update_display()
    
    def handle_advanced_op(self, op):
        """处理高级运算符"""
        if op == '√':
            self.append_input('√')
        elif op == '^':
            self.append_input('^')
        elif op == 'log':
            self.append_input('log')
        elif op in ['sin', 'cos', 'tan']:
            self.append_input(f'{op}(')
        elif op == '!':
            self.append_input('!')
        elif op == 'π':
            self.append_input(str(math.pi))
        elif op == 'e':
            self.append_input(str(math.e))
    
    def calculate_result(self):
        """计算表达式结果"""
        try:
            # 预处理表达式
            expr = self.preprocess_expression(self.current_input)
            
            # 中缀转后缀
            postfix = self.infix_to_postfix(expr)
            
            # 计算后缀表达式
            result = self.evaluate_postfix(postfix)
            
            # 显示结果
            self.current_input = f"{self.current_input}=\n{result}"
            self.update_display()
        except Exception as e:
            messagebox.showerror("错误", f"计算错误: {str(e)}")
    
    def preprocess_expression(self, expr):
        """预处理表达式：处理负号、常量等"""
        # 处理负号：在-前加0（如-5 → 0-5）
        expr = re.sub(r'(?<![0-9πe)])-', '0-', expr)
        
        # 处理括号内的负号：( -5 → (0-5
        expr = re.sub(r'\(\s*-', '(0-', expr)
        
        # 替换√为sqrt，处理开根号
        expr = expr.replace('√', 'sqrt')
        
        return expr
    
    def infix_to_postfix(self, expr):
        """中缀表达式转后缀表达式（逆波兰式）"""
        precedence = {'+':1, '-':1, '*':2, '/':2, '^':3, 'sqrt':4, 'log':4, 
                     'sin':4, 'cos':4, 'tan':4, '!':4}
        output = []
        stack = []
        
        i = 0
        while i < len(expr):
            c = expr[i]
            
            # 处理数字（包括多位数和小数）
            if c.isdigit() or c == '.':
                num = []
                while i < len(expr) and (expr[i].isdigit() or expr[i] == '.'):
                    num.append(expr[i])
                    i += 1
                output.append(''.join(num))
                continue
            
            # 处理函数（sin, cos, tan, log, sqrt）
            elif c.isalpha():
                func = []
                while i < len(expr) and expr[i].isalpha():
                    func.append(expr[i])
                    i += 1
                stack.append(''.join(func))
                continue
            
            # 处理左括号
            elif c == '(':
                stack.append(c)
            
            # 处理右括号
            elif c == ')':
                while stack and stack[-1] != '(':
                    output.append(stack.pop())
                stack.pop()  # 弹出左括号
            
            # 处理运算符
            else:
                while (stack and stack[-1] != '(' and 
                       precedence.get(stack[-1], 0) >= precedence.get(c, 0)):
                    output.append(stack.pop())
                stack.append(c)
            
            i += 1
        
        # 弹出栈中剩余运算符
        while stack:
            output.append(stack.pop())
        
        return output
    
    def evaluate_postfix(self, postfix):
        """计算后缀表达式"""
        stack = []
        
        for token in postfix:
            if token.replace('.', '').isdigit():  # 处理数字（包括小数）
                stack.append(float(token))
            
            # 处理二元运算符
            elif token in '+-*/^':
                b = stack.pop()
                a = stack.pop()
                if token == '+': stack.append(a + b)
                elif token == '-': stack.append(a - b)
                elif token == '*': stack.append(a * b)
                elif token == '/': stack.append(a / b)
                elif token == '^': stack.append(a ** b)
            
            # 处理一元运算符和函数
            else:
                a = stack.pop()
                if token == 'sqrt': stack.append(math.sqrt(a))
                elif token == 'sin': stack.append(math.sin(math.radians(a)))
                elif token == 'cos': stack.append(math.cos(math.radians(a)))
                elif token == 'tan': stack.append(math.tan(math.radians(a)))
                elif token == 'log': stack.append(math.log10(a))
                elif token == '!': stack.append(math.factorial(int(a)))
        
        return stack[0] if stack else 0
    
    def dec_to_bin(self):
        """十进制转二进制"""
        try:
            num = int(self.current_input)
            self.current_input = f"{num}(Bin)\n{bin(num)[2:]}"
            self.update_display()
        except:
            messagebox.showerror("错误", "请输入有效的十进制数")
    
    def dec_to_hex(self):
        """十进制转十六进制"""
        try:
            num = int(self.current_input)
            self.current_input = f"{num}(Hex)\n{hex(num)[2:].upper()}"
            self.update_display()
            self.is_hex_mode = True
        except:
            messagebox.showerror("错误", "请输入有效的十进制数")
    
    def calculate_crc16(self, data=None):
        """计算CRC16校验值"""
        if not data:
            data = self.current_input.split()
            try:
                data = [int(x, 16) for x in data]
            except:
                messagebox.showerror("错误", "请输入有效的十六进制数，用空格分隔")
                return
        
        crc = 0xFFFF
        for byte in data:
            crc = (crc >> 8) ^ self.crc16_table[(crc ^ byte) & 0xFF]
        
        self.current_input = f"{' '.join(hex(x)[2:] for x in data)}(CRC16)\n{hex(crc)[2:].upper()}"
        self.update_display()

# 主程序
if __name__ == "__main__":
    root = tk.Tk()
    calc = Calculator(root)
    root.mainloop()  